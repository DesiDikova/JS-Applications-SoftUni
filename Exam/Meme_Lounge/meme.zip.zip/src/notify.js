const container = document.getElementById('errorBox');
const spanElement = container.querySelector('span');

export function notify(message) {
    spanElement.textContent = message;
    container.style.display = 'block';

    setTimeout(() => container.style.display = 'none', 3000);
}